-- # A Mysql Backup System
-- # Export created: 2016/12/01 on 10:03
-- # Database : componente
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

-- # Tabel structure for table `bancos`
DROP TABLE  IF EXISTS `bancos`;
CREATE TABLE `bancos` (
  `id_banco` int(3) NOT NULL AUTO_INCREMENT,
  `nombre` text NOT NULL,
  PRIMARY KEY (`id_banco`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO `bancos` (`id_banco`, `nombre`) VALUES (1, 'Banco Canarias de Venezuela'), 
(2, 'Banco de Venezuela'), 
(3, 'Corp Banca'), 
(4, 'Banco Provincial'), 
(6, 'Banco Activo'), 
(9, 'Banesco'), 
(10, 'BFC');

-- # Tabel structure for table `compras`
DROP TABLE  IF EXISTS `compras`;
CREATE TABLE `compras` (
  `cod_compra` int(15) NOT NULL,
  `id_prov` int(11) NOT NULL,
  `id_emp` int(10) NOT NULL,
  `fecha_actual` date NOT NULL,
  `forma_pago` enum('efectivo','deposito / transferencia','credito','') COLLATE utf8_spanish_ci NOT NULL,
  `banco` text COLLATE utf8_spanish_ci NOT NULL,
  `nro_cuenta` int(30) NOT NULL,
  `nro_comprobante` int(30) NOT NULL,
  `impuesto` int(10) NOT NULL,
  `subtot` int(10) NOT NULL,
  `tot` int(10) NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`cod_compra`),
  KEY `id_proveedor` (`id_prov`),
  KEY `id_emp` (`id_emp`),
  CONSTRAINT `compras_ibfk_1` FOREIGN KEY (`id_prov`) REFERENCES `proveedores` (`id_prov`),
  CONSTRAINT `compras_ibfk_2` FOREIGN KEY (`id_emp`) REFERENCES `empleados` (`id_emp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `compras` (`cod_compra`, `id_prov`, `id_emp`, `fecha_actual`, `forma_pago`, `banco`, `nro_cuenta`, `nro_comprobante`, `impuesto`, `subtot`, `tot`, `status`) VALUES (1, 29, 1, '2016-12-01', 'efectivo', '', 0, 0, 750000, 6250000, 7000000, 'activo'), 
(2, 29, 1, '2016-12-01', 'deposito / transferencia', 'Banco de Venezuela', 108, 2501637, 510000, 4250000, 4760000, 'activo'), 
(3, 29, 1, '2016-12-01', '', '', 0, 0, 3600, 30000, 33600, 'activo');

SET FOREIGN_KEY_CHECKS = 1;
COMMIT;
SET AUTOCOMMIT = 1; 
