-- # A Mysql Backup System
-- # Export created: 2016/12/01 on 01:48
-- # Database : componente
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

-- # Tabel structure for table `bancos`
DROP TABLE  IF EXISTS `bancos`;
CREATE TABLE `bancos` (
  `id_banco` int(3) NOT NULL AUTO_INCREMENT,
  `nombre` text NOT NULL,
  PRIMARY KEY (`id_banco`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO `bancos` (`id_banco`, `nombre`) VALUES (1, 'Banco Canarias de Venezuela'), 
(2, 'Banco de Venezuela'), 
(3, 'Corp Banca'), 
(4, 'Banco Provincial'), 
(6, 'Banco Activo'), 
(9, 'Banesco'), 
(10, 'BFC');

-- # Tabel structure for table `bitacora`
DROP TABLE  IF EXISTS `bitacora`;
CREATE TABLE `bitacora` (
  `id_mov` int(11) NOT NULL AUTO_INCREMENT,
  `responsable` text NOT NULL,
  `accion` text NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_mov`)
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8;

INSERT INTO `bitacora` (`id_mov`, `responsable`, `accion`, `fecha`) VALUES (1, 'osward', 'inicio sesion', '2016-11-08 11:01:17'), 
(3, 'Osward', 'Inicio Sesión', '2016-11-08 11:37:12'), 
(4, 'Osward', 'Inicio Sesión', '2016-11-08 11:38:19'), 
(5, 'Osward', 'Inicio Sesión', '2016-11-08 11:38:44'), 
(6, 'Osward', 'Inicio Sesión', '2016-11-08 11:39:33'), 
(7, 'Osward', 'Inicio Sesión', '2016-11-08 11:39:41'), 
(8, 'Osward', 'Inicio Sesión', '2016-11-08 13:50:17'), 
(9, 'Osward', 'Inicio Sesión', '2016-11-08 14:28:49'), 
(10, 'Osward', 'Inicio Sesión', '2016-11-08 14:31:36'), 
(11, 'Osward', 'Inicio Sesión', '2016-11-08 14:33:22'), 
(12, 'Osward', 'Inicio Sesión', '2016-11-08 18:45:00'), 
(13, 'Osward', 'Inicio Sesión', '2016-11-09 19:24:18'), 
(14, 'Osward', 'Inicio Sesión', '2016-11-09 23:32:00'), 
(15, 'Osward', 'Inicio Sesión', '2016-11-10 08:10:20'), 
(16, 'Osward', 'Inicio Sesión', '2016-11-10 22:00:08'), 
(17, 'Osward', 'Inicio Sesión', '2016-11-10 22:00:09'), 
(18, 'Osward', 'Inicio Sesión', '2016-11-11 07:48:58'), 
(19, 'Osward', 'Inicio Sesión', '2016-11-11 15:44:37'), 
(20, 'Osward', 'Inicio Sesión', '2016-11-11 16:39:48'), 
(21, 'Osward', 'Inicio Sesión', '2016-11-12 09:36:06'), 
(22, 'Osward', 'Inicio Sesión', '2016-11-12 09:45:35'), 
(23, 'Osward', 'Inicio Sesión', '2016-11-12 15:08:41'), 
(24, 'Osward', 'Inicio Sesión', '2016-11-12 15:08:43'), 
(25, 'Osward', 'Inicio Sesión', '2016-11-12 17:42:39'), 
(26, 'Osward', 'Inicio Sesión', '2016-11-13 18:42:55'), 
(27, 'Osward', 'Inicio Sesión', '2016-11-13 18:44:22'), 
(28, 'Osward', 'Inicio Sesión', '2016-11-13 18:46:16'), 
(29, 'Osward', 'Inicio Sesión', '2016-11-13 22:09:39'), 
(30, 'Osward', 'Inicio Sesión', '2016-11-17 23:14:49'), 
(31, 'Osward', 'Registró un nuevo cliente', '2016-11-18 00:02:42'), 
(32, 'Osward', 'Registró un nuevo cliente', '2016-11-18 00:06:35'), 
(33, 'Osward', 'Eliminó a un cliente', '2016-11-18 00:12:41'), 
(34, 'Osward', 'Eliminó a un cliente', '2016-11-18 00:12:43'), 
(35, 'Osward', 'Eliminó a un cliente', '2016-11-18 00:12:45'), 
(36, 'Osward', 'Eliminó a un cliente', '2016-11-18 00:12:47'), 
(37, 'Osward', 'Eliminó a un cliente', '2016-11-18 00:12:49'), 
(38, 'Osward', 'Eliminó a un cliente', '2016-11-18 00:12:51'), 
(39, 'Osward', 'Eliminó a un cliente', '2016-11-18 00:12:53'), 
(40, 'Osward', 'Actualizó los datos de un cliente', '2016-11-18 00:33:38'), 
(41, 'Osward', 'Inició sesión', '2016-11-18 00:43:58'), 
(42, 'Osward', 'Creó una nueva categoria', '2016-11-18 00:47:42'), 
(43, 'Osward', 'Inició sesión', '2016-11-23 02:25:20'), 
(44, 'Osward', 'Inició sesión', '2016-11-24 23:16:48'), 
(45, 'Osward', 'Inició sesión', '2016-11-28 21:29:39'), 
(46, 'Osward', 'Inició sesión', '2016-11-28 21:39:25'), 
(47, 'Osward', 'Registró un nuevo cliente', '2016-11-28 21:50:15'), 
(48, 'Osward', 'Registró un nuevo cliente', '2016-11-28 22:50:55'), 
(49, 'Osward', 'Realizó una nueva compra', '2016-11-29 00:29:57'), 
(50, 'Osward', 'Inició sesión', '2016-11-29 12:31:01'), 
(51, 'Osward', 'Inició sesión', '2016-11-30 13:21:31'), 
(52, 'Osward', 'Inició sesión', '2016-11-30 13:55:42'), 
(53, 'Osward', 'Realizó un presupuesto', '2016-11-30 15:09:35'), 
(54, 'Osward', 'Inició sesión', '2016-11-30 17:37:07'), 
(55, 'Osward', 'Inició sesión', '2016-11-30 23:29:08'), 
(56, 'Osward', 'Inició sesión', '2016-11-30 23:32:16'), 
(57, 'Osward', 'Actualizó los datos de un usuario', '2016-11-30 23:47:22'), 
(58, 'Osward', 'Registró un nuevo usuario', '2016-11-30 23:55:57'), 
(59, 'Osward', 'Registró un nuevo usuario', '2016-11-30 23:56:36'), 
(60, 'Osward', 'Eliminó un usuario', '2016-11-30 23:57:45'), 
(61, 'Osward', 'Eliminó un usuario', '2016-11-30 23:57:59'), 
(62, 'Osward', 'Eliminó un usuario', '2016-12-01 00:00:04'), 
(63, 'jhonny', 'Inició sesión', '2016-12-01 00:02:48'), 
(64, 'Osward', 'Inició sesión', '2016-12-01 00:09:30'), 
(65, 'Osward', 'Inició sesión', '2016-12-01 00:09:56'), 
(66, 'Osward', 'Inició sesión', '2016-12-01 00:11:20'), 
(67, 'Osward', 'Inició sesión', '2016-12-01 00:12:25'), 
(68, 'Osward', 'Registró un nuevo proveedor', '2016-12-01 00:13:55'), 
(69, 'Osward', 'Registró un nuevo proveedor', '2016-12-01 00:15:03'), 
(70, 'Osward', 'Realizó una nueva compra', '2016-12-01 00:17:16'), 
(71, 'Osward', 'Realizó una nueva compra', '2016-12-01 00:20:50'), 
(72, 'Osward', 'Eliminó a un cliente', '2016-12-01 00:39:26'), 
(73, 'Osward', 'Eliminó a un cliente', '2016-12-01 00:39:28'), 
(74, 'Osward', 'Eliminó a un cliente', '2016-12-01 00:39:30'), 
(75, 'Osward', 'Eliminó a un cliente', '2016-12-01 00:39:32'), 
(76, 'Osward', 'Eliminó a un cliente', '2016-12-01 00:39:34'), 
(77, 'Osward', 'Eliminó a un cliente', '2016-12-01 00:39:35'), 
(78, 'Osward', 'Eliminó a un cliente', '2016-12-01 00:39:38'), 
(79, 'Osward', 'Registró un nuevo proveedor', '2016-12-01 00:46:49'), 
(80, 'Osward', 'Registró un nuevo producto', '2016-12-01 00:47:05'), 
(81, 'jhonny', 'Inició sesión', '2016-12-01 00:50:05'), 
(82, 'Osward', 'Inició sesión', '2016-12-01 01:22:27'), 
(83, 'Osward', 'Realizó una nueva compra', '2016-12-01 01:32:27'), 
(84, 'Osward', 'Inició sesión', '2016-12-01 09:32:33'), 
(85, 'Osward', 'Realizó una nueva compra', '2016-12-01 09:42:14'), 
(86, 'Osward', 'Inició sesión', '2016-12-01 09:50:45'), 
(87, 'Osward', 'Inició sesión', '2016-12-01 10:06:01'), 
(88, 'Osward', 'Actualizó los datos de un cliente', '2016-12-01 10:15:40'), 
(89, 'Osward', 'Inició sesión', '2016-12-01 10:48:04');

-- # Tabel structure for table `categorias`
DROP TABLE  IF EXISTS `categorias`;
CREATE TABLE `categorias` (
  `id_cat` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_cat`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `categorias` (`id_cat`, `nombre`, `descripcion`) VALUES (2, 'Ferretería', '..'), 
(3, 'Químicos', 'De todo tipo'), 
(4, 'Pinturas', 'pinturas para interiores y exteriores.');

-- # Tabel structure for table `clientes`
DROP TABLE  IF EXISTS `clientes`;
CREATE TABLE `clientes` (
  `id_cliente` int(11) NOT NULL AUTO_INCREMENT,
  `rif` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `razon_social` text COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` text COLLATE utf8_spanish_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_cliente`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `clientes` (`id_cliente`, `rif`, `razon_social`, `telefono`, `email`, `direccion`, `status`) VALUES (3, 'J-20989357-0', 'Migo, C.A', '0244-3962442', 'ojpr15@gmail.com', 'La Victoria', 'activo'), 
(4, 'J-25065787-0', 'Dev services', '0248-3659841', 'admin@gmail.com', 'direccion. ', 'activo'), 
(5, 'J-25065787-1', 'a', '0248-3659841', 'admin@gmail.com', 'a', 'inactivo'), 
(6, 'J-25065787-2', 'asd', '0248-3659841', 'admin@gmail.com', 'asd', 'inactivo'), 
(7, 'J-03842286-0', 'Alicia Vásquez', '0244-4478908', 'Alicia@hotmail.com', 'La Victoria', 'activo'), 
(8, 'J-25525110-0', 'Gabriel Flores', '0414-5436789', 'Gf@gmail.com', 'cagua', 'activo'), 
(9, 'J-26180853-0', 'Alexis ', '0244-5667894', 'Alexis@gmail.com', 'La Victoria', 'activo'), 
(10, 'J-25065783-0', 'asd', '0244-2986656', 'asdasd@asd', 'asd', 'inactivo'), 
(11, 'J-25065783-0', 'asdasd', '0244-2986656', 'asdasd@asd', 'asdasd', 'inactivo'), 
(12, 'J-25065783-0', 'asdsad', '0244-2986656', 'asdasd@asd', 'asdasd', 'inactivo'), 
(13, 'J-25065783-0', 'asdsad', '0244-2986656', 'asdasd@asd', 'asdasd', 'inactivo'), 
(14, 'J-25065783-0', 'asdsad', '0244-2986656', 'asdasd@asd', 'asdasd', 'inactivo'), 
(15, 'J-25065789-0', 'jhonny', '0244-2986656', 'asdasd@asd', 'asdsa', 'inactivo'), 
(16, 'J-25065789-0', 'asd', '0244-2986656', 'asdasd@asd', 'asdsa', 'inactivo'), 
(17, 'J-25065758-1', 'asd', '0244-2986656', 'asdasd@asd', 'asd', 'inactivo'), 
(18, 'J-25658963-0', 'asd', '0244-2986656', 'asdasd@asd', 'aasd', 'inactivo'), 
(19, 'J-25658963-0', 'asd', '0244-2986656', 'asdasd@asd', 'aasd', 'inactivo'), 
(20, 'J-25658963-0', 'asd', '0244-2986656', 'asdasd@asd', 'aasd', 'inactivo'), 
(21, 'J-25065758-4', 'asd', '0244-2986656', 'asdasd@asd', 'asd', 'inactivo'), 
(22, 'J-25065783-0', 23, '0244-2986656', 'jhonnyjosearana@gmail.com', 'a', 'inactivo'), 
(23, 'J-25065783-5', 'asd', '0244-2986656', 'asdasd@asd', 'a', 'inactivo');

-- # Tabel structure for table `compras`
DROP TABLE  IF EXISTS `compras`;
CREATE TABLE `compras` (
  `cod_compra` int(15) NOT NULL,
  `id_prov` int(11) NOT NULL,
  `id_emp` int(10) NOT NULL,
  `fecha_actual` date NOT NULL,
  `forma_pago` enum('efectivo','deposito / transferencia','credito','') COLLATE utf8_spanish_ci NOT NULL,
  `banco` text COLLATE utf8_spanish_ci NOT NULL,
  `nro_cuenta` int(30) NOT NULL,
  `nro_comprobante` int(30) NOT NULL,
  `impuesto` int(10) NOT NULL,
  `subtot` int(10) NOT NULL,
  `tot` int(10) NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`cod_compra`),
  KEY `id_proveedor` (`id_prov`),
  KEY `id_emp` (`id_emp`),
  CONSTRAINT `compras_ibfk_1` FOREIGN KEY (`id_prov`) REFERENCES `proveedores` (`id_prov`),
  CONSTRAINT `compras_ibfk_2` FOREIGN KEY (`id_emp`) REFERENCES `empleados` (`id_emp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `compras` (`cod_compra`, `id_prov`, `id_emp`, `fecha_actual`, `forma_pago`, `banco`, `nro_cuenta`, `nro_comprobante`, `impuesto`, `subtot`, `tot`, `status`) VALUES (1, 29, 1, '2016-12-01', 'efectivo', '', 0, 0, 750000, 6250000, 7000000, 'activo'), 
(2, 29, 1, '2016-12-01', 'deposito / transferencia', 'Banco de Venezuela', 108, 2501637, 510000, 4250000, 4760000, 'activo'), 
(3, 29, 1, '2016-12-01', '', '', 0, 0, 3600, 30000, 33600, 'activo'), 
(4, 29, 1, '2016-12-01', 'deposito / transferencia', 'Banco de Venezuela', 2147483647, 9009, 3900, 32500, 36400, 'activo');

-- # Tabel structure for table `det_compra`
DROP TABLE  IF EXISTS `det_compra`;
CREATE TABLE `det_compra` (
  `cod_compra` int(15) NOT NULL,
  `cod_prod` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `cantidad` int(10) NOT NULL,
  `precio` int(10) NOT NULL,
  KEY `cod_prod` (`cod_prod`),
  KEY `cod_compra` (`cod_compra`),
  CONSTRAINT `det_compra_ibfk_1` FOREIGN KEY (`cod_compra`) REFERENCES `compras` (`cod_compra`),
  CONSTRAINT `det_compra_ibfk_2` FOREIGN KEY (`cod_prod`) REFERENCES `productos` (`cod_prod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `det_compra` (`cod_compra`, `cod_prod`, `cantidad`, `precio`) VALUES (1, 'CER025', 2500, 2500), 
(2, 'CER025', 500, 2500), 
(2, 'CORRTEF002', 1000, 3000), 
(3, 'CER025', 12, 2500), 
(4, 'CER025', 13, 2500);

-- # Tabel structure for table `det_presu`
DROP TABLE  IF EXISTS `det_presu`;
CREATE TABLE `det_presu` (
  `cod_presu` int(15) NOT NULL,
  `cod_prod` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `cantidad` int(10) NOT NULL,
  `precio` int(10) NOT NULL,
  KEY `cod_prod` (`cod_prod`),
  KEY `cod_presu` (`cod_presu`),
  CONSTRAINT `det_presu_ibfk_1` FOREIGN KEY (`cod_presu`) REFERENCES `presupuestos` (`cod_presu`),
  CONSTRAINT `det_presu_ibfk_2` FOREIGN KEY (`cod_prod`) REFERENCES `productos` (`cod_prod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `det_presu` (`cod_presu`, `cod_prod`, `cantidad`, `precio`) VALUES (1, 0001, 5, 1000), 
(2, 0001, 10, 1000), 
(3, 'CORRTEF002', 12, 3120), 
(3, 'HIERR4421', 23, 2679);

-- # Tabel structure for table `det_venta`
DROP TABLE  IF EXISTS `det_venta`;
CREATE TABLE `det_venta` (
  `cod_venta` int(15) NOT NULL,
  `cod_prod` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `cantidad` int(10) NOT NULL,
  `precio` int(10) NOT NULL,
  KEY `cod_prod` (`cod_prod`),
  KEY `cod_venta` (`cod_venta`),
  CONSTRAINT `det_venta_ibfk_1` FOREIGN KEY (`cod_venta`) REFERENCES `ventas` (`cod_venta`),
  CONSTRAINT `det_venta_ibfk_2` FOREIGN KEY (`cod_prod`) REFERENCES `productos` (`cod_prod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `det_venta` (`cod_venta`, `cod_prod`, `cantidad`, `precio`) VALUES (1, 0001, 5, 1000), 
(2, 0001, 5, 1000), 
(3, 0001, 10, 1000), 
(4, 0001, 5, 1000), 
(5, 0001, 5, 1000), 
(6, 0001, 5, 1000), 
(7, 0001, 5, 1000), 
(8, 0001, 5, 1000), 
(9, 0001, 5, 1000), 
(10, 0001, 5, 1000), 
(11, 0001, 5, 1000), 
(12, 0001, 5, 1000), 
(13, 0001, 23, 1000), 
(14, 0001, 12, 1000), 
(15, 'PIEGRIS005', 500, 458), 
(15, 'CORRTEF002', 1100, 3120), 
(16, 'CER025', 3000, 2500);

-- # Tabel structure for table `empleados`
DROP TABLE  IF EXISTS `empleados`;
CREATE TABLE `empleados` (
  `id_emp` int(11) NOT NULL AUTO_INCREMENT,
  `ci_usuario` int(10) NOT NULL,
  `primer_nombre` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `primer_apellido` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `username` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `rol` enum('Administrador','empleado','','') COLLATE utf8_spanish_ci NOT NULL,
  `pregunta` text COLLATE utf8_spanish_ci NOT NULL,
  `respuesta` text COLLATE utf8_spanish_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8_spanish_ci NOT NULL DEFAULT 'activo',
  PRIMARY KEY (`id_emp`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `empleados` (`id_emp`, `ci_usuario`, `primer_nombre`, `primer_apellido`, `username`, `password`, `rol`, `pregunta`, `respuesta`, `status`) VALUES (1, 20989357, 'Osward', 'Jr', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Administrador', 'Nombre de su abuela', 'alicia', 'activo'), 
(2, 25065787, 'jhonny', 'arana', 'arana', '21232f297a57a5a743894a0e4a801fc3', 'empleado', 'Lugar de nacimiento de la madre', 'cagua', 'activo');

-- # Tabel structure for table `presupuestos`
DROP TABLE  IF EXISTS `presupuestos`;
CREATE TABLE `presupuestos` (
  `cod_presu` int(15) NOT NULL,
  `id_cliente` int(15) NOT NULL,
  `id_emp` int(15) NOT NULL,
  `fecha_actual` date NOT NULL,
  `fecha_vencimiento` enum('5 Días','','','') COLLATE utf8_spanish_ci NOT NULL,
  `impuesto` int(15) NOT NULL,
  `descuento` int(15) NOT NULL,
  `subtot` int(15) NOT NULL,
  `tot` int(15) NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`cod_presu`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_emp` (`id_emp`),
  CONSTRAINT `presupuestos_ibfk_1` FOREIGN KEY (`id_emp`) REFERENCES `empleados` (`id_emp`),
  CONSTRAINT `presupuestos_ibfk_2` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `presupuestos` (`cod_presu`, `id_cliente`, `id_emp`, `fecha_actual`, `fecha_vencimiento`, `impuesto`, `descuento`, `subtot`, `tot`, `status`) VALUES (1, 3, 1, '2016-11-08', '', 600, 0, 5000, 5600, 'activo'), 
(2, 4, 1, '2016-11-08', '5 Días', 1200, 0, 10000, 11200, 'activo'), 
(3, 3, 1, '2016-11-30', '5 Días', 11887, 0, 99057, 110944, 'activo');

-- # Tabel structure for table `productos`
DROP TABLE  IF EXISTS `productos`;
CREATE TABLE `productos` (
  `cod_prod` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `modelo` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `peso` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `color` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `garantia` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `p_compra` int(10) NOT NULL,
  `p_venta` int(10) NOT NULL,
  `stock` int(10) NOT NULL,
  `stock_minimo` int(10) NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8_spanish_ci NOT NULL,
  `procedencia` enum('nacional','internacional') COLLATE utf8_spanish_ci NOT NULL,
  `id_cat` int(11) NOT NULL,
  PRIMARY KEY (`cod_prod`),
  KEY `id_cat` (`id_cat`),
  CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`id_cat`) REFERENCES `categorias` (`id_cat`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `productos` (`cod_prod`, `descripcion`, `modelo`, `peso`, `color`, `garantia`, `p_compra`, `p_venta`, `stock`, `stock_minimo`, `status`, `procedencia`, `id_cat`) VALUES (0001, 'Tornillos', '.', '', '', '', 5000, 1000, 1050, 100, 'inactivo', 'nacional', 2), 
('CER025', 'Cerraduras CISA', 'Embutir 25mm', '', '', '', 2500, 2500, 25, 100, 'activo', 'nacional', 2), 
('CORRTEF002', 'Corredera Telescópica ', 'Ferrari 30cm', '', '', '', 3000, 3120, 1100, 100, 'activo', 'nacional', 2), 
('HIERR4421', 'Herramientas Multiuso', 'Premiun', '5kg', 'Negro', '6 meses', 2679, 3350, 1200, 100, 'activo', 'nacional', 2), 
('PIEGRIS005', 'Pie de amigo gris', '12x14', '', '', '', 458, 458, 2500, 100, 'activo', 'internacional', 2), 
('RAMHAIER005', 'Ramplus de hierro', 'Inct 0.5pulg', '', '', '', 192, 350, 1000, 100, 'activo', 'internacional', 2);

-- # Tabel structure for table `proveedores`
DROP TABLE  IF EXISTS `proveedores`;
CREATE TABLE `proveedores` (
  `id_prov` int(11) NOT NULL AUTO_INCREMENT,
  `rif` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `razon_social` text COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` text COLLATE utf8_spanish_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_prov`),
  UNIQUE KEY `rif` (`rif`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `proveedores` (`id_prov`, `rif`, `razon_social`, `telefono`, `email`, `direccion`, `status`) VALUES (29, 'J-25068787-0', 'jhonny arana', '0244-2986656', 'jhonnyjosearana@gmail.com', 'cagua', 'activo');

-- # Tabel structure for table `utilidades`
DROP TABLE  IF EXISTS `utilidades`;
CREATE TABLE `utilidades` (
  `impuesto` int(4) NOT NULL,
  `ven_presu` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `utilidades` (`impuesto`, `ven_presu`) VALUES (12, 5);

-- # Tabel structure for table `ventas`
DROP TABLE  IF EXISTS `ventas`;
CREATE TABLE `ventas` (
  `cod_venta` int(15) NOT NULL,
  `id_cliente` int(15) NOT NULL,
  `id_emp` int(15) NOT NULL,
  `fecha_actual` date NOT NULL,
  `forma_pago` enum('efectivo','deposito / transferencia','credito','') COLLATE utf8_spanish_ci NOT NULL,
  `banco` text COLLATE utf8_spanish_ci NOT NULL,
  `nro_cuenta` int(30) NOT NULL,
  `nro_comprobante` int(30) NOT NULL,
  `impuesto` int(15) NOT NULL,
  `descuento` int(15) NOT NULL,
  `subtot` int(15) NOT NULL,
  `tot` int(15) NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`cod_venta`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_emp` (`id_emp`),
  CONSTRAINT `ventas_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`),
  CONSTRAINT `ventas_ibfk_2` FOREIGN KEY (`id_emp`) REFERENCES `empleados` (`id_emp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `ventas` (`cod_venta`, `id_cliente`, `id_emp`, `fecha_actual`, `forma_pago`, `banco`, `nro_cuenta`, `nro_comprobante`, `impuesto`, `descuento`, `subtot`, `tot`, `status`) VALUES (1, 3, 1, '2016-10-27', '', '', 0, 0, 600, 0, 5000, 5600, 'activo'), 
(2, 3, 1, '2016-10-27', '', 'BNC', 2147483647, 6565456, 600, 0, 5000, 5600, 'activo'), 
(3, 3, 1, '2016-10-27', '', 'BFC', 2147483647, 77396137, 1200, 0, 10000, 11200, 'activo'), 
(4, 3, 1, '2016-10-27', '', '', 0, 0, 600, 0, 5000, 5600, 'activo'), 
(5, 3, 1, '2016-10-27', '', 'BNC', 2147483647, 423434343, 600, 0, 5000, 5600, 'activo'), 
(6, 3, 1, '2016-10-27', '', 'BFC', 2147483647, 253452, 600, 0, 5000, 5600, 'activo'), 
(7, 3, 1, '2016-10-27', '', 'CARONI', 2147483647, 423323233, 600, 0, 5000, 5600, 'activo'), 
(8, 3, 1, '2016-10-28', 'efectivo', '', 0, 0, 600, 0, 5000, 5600, 'activo'), 
(9, 3, 1, '2016-10-28', 'deposito / transferencia', 'BFC C.A', 2147483647, 2147483647, 600, 0, 5000, 5600, 'activo'), 
(10, 3, 1, '2016-10-28', 'credito', '', 0, 0, 600, 0, 5000, 5600, 'activo'), 
(11, 3, 1, '2016-10-28', 'efectivo', '', 0, 0, 600, 0, 5000, 5600, 'activo'), 
(12, 3, 1, '2016-10-28', 'deposito / transferencia', 'bfc', 2147483647, 2147483647, 600, 0, 5000, 5600, 'activo'), 
(13, 3, 1, '2016-11-08', 'deposito / transferencia', 'Banco Canarias de Venezuela', 0, 0, 2760, 207000, 23000, 232760, 'activo'), 
(14, 3, 1, '2016-11-08', 'deposito / transferencia', 'Banco de Venezuela', 34343434, 343434, 1440, 108000, 12000, 121440, 'activo'), 
(15, 3, 1, '2016-11-08', 'deposito / transferencia', 'Banco de Venezuela', 2147483647, 707876, 439320, 43932000, 3661000, 48032320, 'activo'), 
(16, 3, 1, '2016-12-01', 'efectivo', '', 0, 0, 900000, 90000000, 7500000, 98400000, 'activo');

SET FOREIGN_KEY_CHECKS = 1;
COMMIT;
SET AUTOCOMMIT = 1; 
