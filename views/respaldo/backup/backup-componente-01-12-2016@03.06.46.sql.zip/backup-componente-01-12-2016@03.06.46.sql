-- # A Mysql Backup System
-- # Export created: 2016/12/01 on 03:06
-- # Database : componente
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

-- # Tabel structure for table `bancos`
DROP TABLE  IF EXISTS `bancos`;
CREATE TABLE `bancos` (
  `id_banco` int(3) NOT NULL AUTO_INCREMENT,
  `nombre` text NOT NULL,
  PRIMARY KEY (`id_banco`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO `bancos` (`id_banco`, `nombre`) VALUES (1, 'Banco Canarias de Venezuela'), 
(2, 'Banco de Venezuela'), 
(3, 'Corp Banca'), 
(4, 'Banco Provincial'), 
(6, 'Banco Activo'), 
(9, 'Banesco'), 
(10, 'BFC'), 
(11, 'Banco del Caribe');

-- # Tabel structure for table `bitacora`
DROP TABLE  IF EXISTS `bitacora`;
CREATE TABLE `bitacora` (
  `id_mov` int(11) NOT NULL AUTO_INCREMENT,
  `responsable` text NOT NULL,
  `accion` text NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_mov`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8;

INSERT INTO `bitacora` (`id_mov`, `responsable`, `accion`, `fecha`) VALUES (1, 'osward', 'inicio sesion', '2016-11-08 11:01:17'), 
(3, 'Osward', 'Inicio Sesión', '2016-11-08 11:37:12'), 
(4, 'Osward', 'Inicio Sesión', '2016-11-08 11:38:19'), 
(5, 'Osward', 'Inicio Sesión', '2016-11-08 11:38:44'), 
(6, 'Osward', 'Inicio Sesión', '2016-11-08 11:39:33'), 
(7, 'Osward', 'Inicio Sesión', '2016-11-08 11:39:41'), 
(8, 'Osward', 'Inicio Sesión', '2016-11-08 13:50:17'), 
(9, 'Osward', 'Inicio Sesión', '2016-11-08 14:28:49'), 
(10, 'Osward', 'Inicio Sesión', '2016-11-08 14:31:36'), 
(11, 'Osward', 'Inicio Sesión', '2016-11-08 14:33:22'), 
(12, 'Osward', 'Inicio Sesión', '2016-11-08 18:45:00'), 
(13, 'Osward', 'Inicio Sesión', '2016-11-09 19:24:18'), 
(14, 'Osward', 'Inicio Sesión', '2016-11-09 23:32:00'), 
(15, 'Osward', 'Inicio Sesión', '2016-11-10 08:10:20'), 
(16, 'Osward', 'Inicio Sesión', '2016-11-10 22:00:08'), 
(17, 'Osward', 'Inicio Sesión', '2016-11-10 22:00:09'), 
(18, 'Osward', 'Inicio Sesión', '2016-11-11 07:48:58'), 
(19, 'Osward', 'Inicio Sesión', '2016-11-11 15:44:37'), 
(20, 'Osward', 'Inicio Sesión', '2016-11-11 16:39:48'), 
(21, 'Osward', 'Inicio Sesión', '2016-11-12 09:36:06'), 
(22, 'Osward', 'Inicio Sesión', '2016-11-12 09:45:35'), 
(23, 'Osward', 'Inicio Sesión', '2016-11-12 15:08:41'), 
(24, 'Osward', 'Inicio Sesión', '2016-11-12 15:08:43'), 
(25, 'Osward', 'Inicio Sesión', '2016-11-12 17:42:39'), 
(26, 'Osward', 'Inicio Sesión', '2016-11-13 18:42:55'), 
(27, 'Osward', 'Inicio Sesión', '2016-11-13 18:44:22'), 
(28, 'Osward', 'Inicio Sesión', '2016-11-13 18:46:16'), 
(29, 'Osward', 'Inicio Sesión', '2016-11-13 22:09:39'), 
(30, 'Osward', 'Inicio Sesión', '2016-11-17 23:14:49'), 
(31, 'Osward', 'Registró un nuevo cliente', '2016-11-18 00:02:42'), 
(32, 'Osward', 'Registró un nuevo cliente', '2016-11-18 00:06:35'), 
(33, 'Osward', 'Eliminó a un cliente', '2016-11-18 00:12:41'), 
(34, 'Osward', 'Eliminó a un cliente', '2016-11-18 00:12:43'), 
(35, 'Osward', 'Eliminó a un cliente', '2016-11-18 00:12:45'), 
(36, 'Osward', 'Eliminó a un cliente', '2016-11-18 00:12:47'), 
(37, 'Osward', 'Eliminó a un cliente', '2016-11-18 00:12:49'), 
(38, 'Osward', 'Eliminó a un cliente', '2016-11-18 00:12:51'), 
(39, 'Osward', 'Eliminó a un cliente', '2016-11-18 00:12:53'), 
(40, 'Osward', 'Actualizó los datos de un cliente', '2016-11-18 00:33:38'), 
(41, 'Osward', 'Inició sesión', '2016-11-18 00:43:58'), 
(42, 'Osward', 'Creó una nueva categoria', '2016-11-18 00:47:42'), 
(43, 'Osward', 'Inició sesión', '2016-11-23 02:25:20'), 
(44, 'Osward', 'Inició sesión', '2016-11-24 23:16:48'), 
(45, 'Osward', 'Inició sesión', '2016-11-28 21:29:39'), 
(46, 'Osward', 'Inició sesión', '2016-11-28 21:39:25'), 
(47, 'Osward', 'Registró un nuevo cliente', '2016-11-28 21:50:15'), 
(48, 'Osward', 'Registró un nuevo cliente', '2016-11-28 22:50:55'), 
(49, 'Osward', 'Realizó una nueva compra', '2016-11-29 00:29:57'), 
(50, 'Osward', 'Inició sesión', '2016-11-29 12:31:01'), 
(51, 'Osward', 'Inició sesión', '2016-11-30 13:21:31'), 
(52, 'Osward', 'Inició sesión', '2016-11-30 13:55:42'), 
(53, 'Osward', 'Realizó un presupuesto', '2016-11-30 15:09:35'), 
(54, 'Osward', 'Inició sesión', '2016-11-30 17:37:07'), 
(55, 'Osward', 'Inició sesión', '2016-11-30 23:29:08'), 
(56, 'Osward', 'Inició sesión', '2016-11-30 23:32:16'), 
(57, 'Osward', 'Actualizó los datos de un usuario', '2016-11-30 23:47:22'), 
(58, 'Osward', 'Registró un nuevo usuario', '2016-11-30 23:55:57'), 
(59, 'Osward', 'Registró un nuevo usuario', '2016-11-30 23:56:36'), 
(60, 'Osward', 'Eliminó un usuario', '2016-11-30 23:57:45'), 
(61, 'Osward', 'Eliminó un usuario', '2016-11-30 23:57:59'), 
(62, 'Osward', 'Eliminó un usuario', '2016-12-01 00:00:04'), 
(63, 'jhonny', 'Inició sesión', '2016-12-01 00:02:48'), 
(64, 'Osward', 'Inició sesión', '2016-12-01 00:09:30'), 
(65, 'Osward', 'Inició sesión', '2016-12-01 00:09:56'), 
(66, 'Osward', 'Inició sesión', '2016-12-01 00:11:20'), 
(67, 'Osward', 'Inició sesión', '2016-12-01 00:12:25'), 
(68, 'Osward', 'Registró un nuevo proveedor', '2016-12-01 00:13:55'), 
(69, 'Osward', 'Registró un nuevo proveedor', '2016-12-01 00:15:03'), 
(70, 'Osward', 'Realizó una nueva compra', '2016-12-01 00:17:16'), 
(71, 'Osward', 'Realizó una nueva compra', '2016-12-01 00:20:50'), 
(72, 'Osward', 'Eliminó a un cliente', '2016-12-01 00:39:26'), 
(73, 'Osward', 'Eliminó a un cliente', '2016-12-01 00:39:28'), 
(74, 'Osward', 'Eliminó a un cliente', '2016-12-01 00:39:30'), 
(75, 'Osward', 'Eliminó a un cliente', '2016-12-01 00:39:32'), 
(76, 'Osward', 'Eliminó a un cliente', '2016-12-01 00:39:34'), 
(77, 'Osward', 'Eliminó a un cliente', '2016-12-01 00:39:35'), 
(78, 'Osward', 'Eliminó a un cliente', '2016-12-01 00:39:38'), 
(79, 'Osward', 'Registró un nuevo proveedor', '2016-12-01 00:46:49'), 
(80, 'Osward', 'Registró un nuevo producto', '2016-12-01 00:47:05'), 
(81, 'jhonny', 'Inició sesión', '2016-12-01 00:50:05'), 
(82, 'Osward', 'Inició sesión', '2016-12-01 01:22:27'), 
(83, 'Osward', 'Realizó una nueva compra', '2016-12-01 01:32:27'), 
(84, 'Osward', 'Inició sesión', '2016-12-01 09:32:33'), 
(85, 'Osward', 'Realizó una nueva compra', '2016-12-01 09:42:14'), 
(86, 'Osward', 'Inició sesión', '2016-12-01 09:50:45'), 
(87, 'Osward', 'Inició sesión', '2016-12-01 10:06:01'), 
(88, 'Osward', 'Actualizó los datos de un cliente', '2016-12-01 10:15:40'), 
(89, 'Osward', 'Inició sesión', '2016-12-01 10:48:04'), 
(90, 'Osward', 'Inició sesión', '2016-12-01 13:24:02'), 
(91, 'Osward', 'Inició sesión', '2016-12-01 13:26:55'), 
(92, 'Osward', 'Registró un nuevo cliente', '2016-12-01 13:29:01'), 
(93, 'Osward', 'Registró un nuevo cliente', '2016-12-01 13:30:27'), 
(94, 'Osward', 'Registró un nuevo cliente', '2016-12-01 13:32:30'), 
(95, 'Osward', 'Registró un nuevo cliente', '2016-12-01 13:34:21'), 
(96, 'Osward', 'Registró un nuevo cliente', '2016-12-01 13:36:19'), 
(97, 'Osward', 'Registró un nuevo cliente', '2016-12-01 13:40:07'), 
(98, 'Osward', 'Realizó una nueva compra', '2016-12-01 13:49:33'), 
(99, 'Osward', 'Inició sesión', '2016-12-01 14:01:52'), 
(100, 'Osward', 'Inició sesión', '2016-12-01 14:13:40'), 
(101, 'Osward', 'Registró un nuevo proveedor', '2016-12-01 14:15:46'), 
(102, 'Osward', 'Realizó una nueva compra', '2016-12-01 14:19:32'), 
(103, 'Osward', 'Registró un nuevo cliente', '2016-12-01 14:22:41'), 
(104, 'Osward', 'Realizó un presupuesto', '2016-12-01 14:24:23');

-- # Tabel structure for table `categorias`
DROP TABLE  IF EXISTS `categorias`;
CREATE TABLE `categorias` (
  `id_cat` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_cat`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `categorias` (`id_cat`, `nombre`, `descripcion`) VALUES (2, 'Ferretería', '..'), 
(3, 'Químicos', 'De todo tipo'), 
(4, 'Pinturas', 'pinturas para interiores y exteriores.');

-- # Tabel structure for table `clientes`
DROP TABLE  IF EXISTS `clientes`;
CREATE TABLE `clientes` (
  `id_cliente` int(11) NOT NULL AUTO_INCREMENT,
  `rif` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `razon_social` text COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` text COLLATE utf8_spanish_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_cliente`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `clientes` (`id_cliente`, `rif`, `razon_social`, `telefono`, `email`, `direccion`, `status`) VALUES (1, 'J-25880366-4', 'Ferreteria San Pedro C.A', '0414-9452962', 'matsanpedro@gmail.com', 'Cagua, Sol y Sombra #04, a una cuadra de la panaderia punto fresco', 'activo'), 
(2, 'J-20989357-0', 'Ferreteria Los Meregotos', '0416-0232306', 'meregotosferre@hotmail.com', 'Calle Los Meregotos c/ La Bermudez', 'activo'), 
(3, 'J-25381767-9', 'Placas Cagua', '0424-3256780', 'masisacagua@gmail.com', 'Carretera Nacional, Turmero, La encrucijada', 'activo'), 
(4, 'J-13546281-1', 'Ferreteria Fayad', '0244-3963571', 'fayadferrema21@gmail.com', 'Centro de Cagua, calle bermudez c/ comercio', 'activo'), 
(5, 'J-15623892-8', 'Imeca Cagua C.A', '0244-3967845', 'imecas_ca@gmail.com', 'Carretera Nacional, entrada de cagua, al lado de Pollo de los Llanos.', 'activo'), 
(6, 'J-10989654-3', 'Ferremetal C.A', '0244-3956782', 'Ferremetal_corinsa@hotmail.com', 'Corinsa, calle pichiche c/ Piar Local 12', 'activo'), 
(7, 'J-20989357-3', 'Ferreteria Cagua', '0244-3962442', 'os@gmail.com', 'Sector Boyaca, Cagua', 'activo');

-- # Tabel structure for table `compras`
DROP TABLE  IF EXISTS `compras`;
CREATE TABLE `compras` (
  `cod_compra` int(15) NOT NULL,
  `id_prov` int(11) NOT NULL,
  `id_emp` int(10) NOT NULL,
  `fecha_actual` date NOT NULL,
  `forma_pago` enum('efectivo','deposito / transferencia','credito','') COLLATE utf8_spanish_ci NOT NULL,
  `banco` text COLLATE utf8_spanish_ci NOT NULL,
  `nro_cuenta` int(30) NOT NULL,
  `nro_comprobante` int(30) NOT NULL,
  `impuesto` int(10) NOT NULL,
  `subtot` int(10) NOT NULL,
  `tot` int(10) NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`cod_compra`),
  KEY `id_proveedor` (`id_prov`),
  KEY `id_emp` (`id_emp`),
  CONSTRAINT `compras_ibfk_1` FOREIGN KEY (`id_prov`) REFERENCES `proveedores` (`id_prov`),
  CONSTRAINT `compras_ibfk_2` FOREIGN KEY (`id_emp`) REFERENCES `empleados` (`id_emp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `compras` (`cod_compra`, `id_prov`, `id_emp`, `fecha_actual`, `forma_pago`, `banco`, `nro_cuenta`, `nro_comprobante`, `impuesto`, `subtot`, `tot`, `status`) VALUES (1, 4, 1, '2016-12-01', 'efectivo', '', 0, 0, 24222, 201850, 226072, 'activo'), 
(2, 7, 1, '2016-12-01', 'efectivo', '', 0, 0, 142824, 1190200, 1333024, 'activo');

-- # Tabel structure for table `det_compra`
DROP TABLE  IF EXISTS `det_compra`;
CREATE TABLE `det_compra` (
  `cod_compra` int(15) NOT NULL,
  `cod_prod` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `cantidad` int(10) NOT NULL,
  `precio` int(10) NOT NULL,
  KEY `cod_prod` (`cod_prod`),
  KEY `cod_compra` (`cod_compra`),
  CONSTRAINT `det_compra_ibfk_1` FOREIGN KEY (`cod_compra`) REFERENCES `compras` (`cod_compra`),
  CONSTRAINT `det_compra_ibfk_2` FOREIGN KEY (`cod_prod`) REFERENCES `productos` (`cod_prod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `det_compra` (`cod_compra`, `cod_prod`, `cantidad`, `precio`) VALUES (1, 'CER025', 2500, 2500), 
(2, 'CER025', 500, 2500), 
(2, 'CORRTEF002', 1000, 3000), 
(3, 'CER025', 12, 2500), 
(4, 'CER025', 13, 2500), 
(1, 'dw8424', 50, 4037), 
(2, 'ganaca001', 1000, 587), 
(2, 'dw53130', 100, 6032);

-- # Tabel structure for table `det_presu`
DROP TABLE  IF EXISTS `det_presu`;
CREATE TABLE `det_presu` (
  `cod_presu` int(15) NOT NULL,
  `cod_prod` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `cantidad` int(10) NOT NULL,
  `precio` int(10) NOT NULL,
  KEY `cod_prod` (`cod_prod`),
  KEY `cod_presu` (`cod_presu`),
  CONSTRAINT `det_presu_ibfk_1` FOREIGN KEY (`cod_presu`) REFERENCES `presupuestos` (`cod_presu`),
  CONSTRAINT `det_presu_ibfk_2` FOREIGN KEY (`cod_prod`) REFERENCES `productos` (`cod_prod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `det_presu` (`cod_presu`, `cod_prod`, `cantidad`, `precio`) VALUES (1, 0001, 5, 1000), 
(2, 0001, 10, 1000), 
(3, 'CORRTEF002', 12, 3120), 
(3, 'HIERR4421', 23, 2679), 
(2, 'ganaca001', 100, 587), 
(2, 'dw53130', 150, 6032);

-- # Tabel structure for table `det_venta`
DROP TABLE  IF EXISTS `det_venta`;
CREATE TABLE `det_venta` (
  `cod_venta` int(15) NOT NULL,
  `cod_prod` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `cantidad` int(10) NOT NULL,
  `precio` int(10) NOT NULL,
  KEY `cod_prod` (`cod_prod`),
  KEY `cod_venta` (`cod_venta`),
  CONSTRAINT `det_venta_ibfk_1` FOREIGN KEY (`cod_venta`) REFERENCES `ventas` (`cod_venta`),
  CONSTRAINT `det_venta_ibfk_2` FOREIGN KEY (`cod_prod`) REFERENCES `productos` (`cod_prod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `det_venta` (`cod_venta`, `cod_prod`, `cantidad`, `precio`) VALUES (1, 0001, 5, 1000), 
(2, 0001, 5, 1000), 
(3, 0001, 10, 1000), 
(4, 0001, 5, 1000), 
(5, 0001, 5, 1000), 
(6, 0001, 5, 1000), 
(7, 0001, 5, 1000), 
(8, 0001, 5, 1000), 
(9, 0001, 5, 1000), 
(10, 0001, 5, 1000), 
(11, 0001, 5, 1000), 
(12, 0001, 5, 1000), 
(13, 0001, 23, 1000), 
(14, 0001, 12, 1000), 
(15, 'PIEGRIS005', 500, 458), 
(15, 'CORRTEF002', 1100, 3120), 
(16, 'CER025', 3000, 2500), 
(2, 'ganaca001', 80, 587), 
(2, 'kw90250', 510, 25000);

-- # Tabel structure for table `empleados`
DROP TABLE  IF EXISTS `empleados`;
CREATE TABLE `empleados` (
  `id_emp` int(11) NOT NULL AUTO_INCREMENT,
  `ci_usuario` int(10) NOT NULL,
  `primer_nombre` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `primer_apellido` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `username` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `rol` enum('Administrador','empleado','','') COLLATE utf8_spanish_ci NOT NULL,
  `pregunta` text COLLATE utf8_spanish_ci NOT NULL,
  `respuesta` text COLLATE utf8_spanish_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8_spanish_ci NOT NULL DEFAULT 'activo',
  PRIMARY KEY (`id_emp`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `empleados` (`id_emp`, `ci_usuario`, `primer_nombre`, `primer_apellido`, `username`, `password`, `rol`, `pregunta`, `respuesta`, `status`) VALUES (1, 20989357, 'Osward', 'Jr', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Administrador', 'Nombre de su abuela', 'margarita', 'activo'), 
(2, 25065787, 'jhonny', 'arana', 'arana', '21232f297a57a5a743894a0e4a801fc3', 'empleado', 'Lugar de nacimiento de la madre', 'cagua', 'activo');

-- # Tabel structure for table `presupuestos`
DROP TABLE  IF EXISTS `presupuestos`;
CREATE TABLE `presupuestos` (
  `cod_presu` int(15) NOT NULL,
  `id_cliente` int(15) NOT NULL,
  `id_emp` int(15) NOT NULL,
  `fecha_actual` date NOT NULL,
  `fecha_vencimiento` enum('5 Días','','','') COLLATE utf8_spanish_ci NOT NULL,
  `impuesto` int(15) NOT NULL,
  `descuento` int(15) NOT NULL,
  `subtot` int(15) NOT NULL,
  `tot` int(15) NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`cod_presu`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_emp` (`id_emp`),
  CONSTRAINT `presupuestos_ibfk_1` FOREIGN KEY (`id_emp`) REFERENCES `empleados` (`id_emp`),
  CONSTRAINT `presupuestos_ibfk_2` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `presupuestos` (`cod_presu`, `id_cliente`, `id_emp`, `fecha_actual`, `fecha_vencimiento`, `impuesto`, `descuento`, `subtot`, `tot`, `status`) VALUES (2, 7, 1, '2016-12-01', '5 Días', 115620, 0, 963500, 1079120, 'activo');

-- # Tabel structure for table `productos`
DROP TABLE  IF EXISTS `productos`;
CREATE TABLE `productos` (
  `cod_prod` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `modelo` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `peso` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `color` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `garantia` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `p_compra` int(10) NOT NULL,
  `p_venta` int(10) NOT NULL,
  `stock` int(10) NOT NULL,
  `stock_minimo` int(10) NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8_spanish_ci NOT NULL,
  `procedencia` enum('nacional','internacional') COLLATE utf8_spanish_ci NOT NULL,
  `id_cat` int(11) NOT NULL,
  PRIMARY KEY (`cod_prod`),
  KEY `id_cat` (`id_cat`),
  CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`id_cat`) REFERENCES `categorias` (`id_cat`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `productos` (`cod_prod`, `descripcion`, `modelo`, `peso`, `color`, `garantia`, `p_compra`, `p_venta`, `stock`, `stock_minimo`, `status`, `procedencia`, `id_cat`) VALUES ('bis076', 'bisagra', 'induma 1/2 pulgada', '', '', '', 399, 520, 1000, 100, 'activo', 'nacional', 2), 
('dw53130', 'broca ', 'cilindro de concreto', '', '', '', 6032, 6550, 1100, 100, 'activo', 'nacional', 2), 
('dw8424', 'disco de corte', 'abrazibo 4 1/2 pulgagas', '', '', '', 4037, 4800, 1050, 100, 'activo', 'nacional', 2), 
('ganaca001', 'gancho canalado', ' 3 cm chromado', '', '', '', 587, 587, 1920, 100, 'activo', 'nacional', 3), 
('kw90250', 'candado anti-sizalla', '50 mm', '', 'bronze', '', 25000, 25000, -10, 100, 'activo', 'nacional', 2);

-- # Tabel structure for table `proveedores`
DROP TABLE  IF EXISTS `proveedores`;
CREATE TABLE `proveedores` (
  `id_prov` int(11) NOT NULL AUTO_INCREMENT,
  `rif` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `razon_social` text COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` text COLLATE utf8_spanish_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_prov`),
  UNIQUE KEY `rif` (`rif`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `proveedores` (`id_prov`, `rif`, `razon_social`, `telefono`, `email`, `direccion`, `status`) VALUES (1, 'J-25880366-4', 'Ferreteria San Pedro C.A', '0414-9452962', 'matsanpedro@gmail.com', 'Cagua, Sol y Sombra #04, a una cuadra de la panaderia punto fresco', 'activo'), 
(2, 'J-20989357-0', 'Ferreteria Los Meregotos', '0416-0232306', 'meregotosferre@hotmail.com', 'Calle Los Meregotos c/ La Bermudez', 'activo'), 
(3, 'J-25381767-9', 'Placas Cagua', '0424-3256780', 'masisacagua@gmail.com', 'Carretera Nacional, Turmero, La encrucijada', 'activo'), 
(4, 'J-13546281-1', 'Ferreteria Fayad', '0244-3963571', 'fayadferrema21@gmail.com', 'Centro de Cagua, calle bermudez c/ comercio', 'activo'), 
(5, 'J-15623892-8', 'Imeca Cagua C.A', '0244-3967845', 'imecas_ca@gmail.com', 'Carretera Nacional, entrada de cagua, al lado de Pollo de los Llanos.', 'activo'), 
(6, 'J-10989654-3', 'Ferremetal C.A', '0244-3956782', 'Ferremetal_corinsa@hotmail.com', 'Corinsa, calle pichiche c/ Piar Local 12', 'activo'), 
(7, 'J-25065787-0', 'ferreteria la victoria', '0244-3956783', 'admin@gmail.com', 'la victoria, sector centro numero 42-b', 'activo');

-- # Tabel structure for table `utilidades`
DROP TABLE  IF EXISTS `utilidades`;
CREATE TABLE `utilidades` (
  `impuesto` int(4) NOT NULL,
  `ven_presu` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `utilidades` (`impuesto`, `ven_presu`) VALUES (10, 5);

-- # Tabel structure for table `ventas`
DROP TABLE  IF EXISTS `ventas`;
CREATE TABLE `ventas` (
  `cod_venta` int(15) NOT NULL,
  `id_cliente` int(15) NOT NULL,
  `id_emp` int(15) NOT NULL,
  `fecha_actual` date NOT NULL,
  `forma_pago` enum('efectivo','deposito / transferencia','credito','') COLLATE utf8_spanish_ci NOT NULL,
  `banco` text COLLATE utf8_spanish_ci NOT NULL,
  `nro_cuenta` int(30) NOT NULL,
  `nro_comprobante` int(30) NOT NULL,
  `impuesto` int(15) NOT NULL,
  `descuento` int(15) NOT NULL,
  `subtot` int(15) NOT NULL,
  `tot` int(15) NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`cod_venta`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_emp` (`id_emp`),
  CONSTRAINT `ventas_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`),
  CONSTRAINT `ventas_ibfk_2` FOREIGN KEY (`id_emp`) REFERENCES `empleados` (`id_emp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `ventas` (`cod_venta`, `id_cliente`, `id_emp`, `fecha_actual`, `forma_pago`, `banco`, `nro_cuenta`, `nro_comprobante`, `impuesto`, `descuento`, `subtot`, `tot`, `status`) VALUES (2, 7, 1, '2016-12-01', 'deposito / transferencia', 'Banco de Venezuela', 2147483647, 0, 1535635, 153563520, 12796960, 167896115, 'activo');

SET FOREIGN_KEY_CHECKS = 1;
COMMIT;
SET AUTOCOMMIT = 1; 
