-- # A Mysql Backup System
-- # Export created: 2016/11/25 on 12:08
-- # Database : componente
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

-- # Tabel structure for table `bancos`
DROP TABLE  IF EXISTS `bancos`;
CREATE TABLE `bancos` (
  `id_banco` int(3) NOT NULL AUTO_INCREMENT,
  `nombre` text NOT NULL,
  PRIMARY KEY (`id_banco`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO `bancos` (`id_banco`, `nombre`) VALUES (1, 'Banco Canarias de Venezuela'), 
(2, 'Banco de Venezuela'), 
(3, 'Corp Banca'), 
(4, 'Banco Provincial'), 
(6, 'Banco Activo'), 
(9, 'Banesco'), 
(10, 'BFC');

-- # Tabel structure for table `bitacora`
DROP TABLE  IF EXISTS `bitacora`;
CREATE TABLE `bitacora` (
  `id_mov` int(11) NOT NULL AUTO_INCREMENT,
  `responsable` text NOT NULL,
  `accion` text NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_mov`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

INSERT INTO `bitacora` (`id_mov`, `responsable`, `accion`, `fecha`) VALUES (1, 'osward', 'inicio sesion', '2016-11-08 11:01:17'), 
(3, 'Osward', 'Inicio Sesión', '2016-11-08 11:37:12'), 
(4, 'Osward', 'Inicio Sesión', '2016-11-08 11:38:19'), 
(5, 'Osward', 'Inicio Sesión', '2016-11-08 11:38:44'), 
(6, 'Osward', 'Inicio Sesión', '2016-11-08 11:39:33'), 
(7, 'Osward', 'Inicio Sesión', '2016-11-08 11:39:41'), 
(8, 'Osward', 'Inicio Sesión', '2016-11-08 13:50:17'), 
(9, 'Osward', 'Inicio Sesión', '2016-11-08 14:28:49'), 
(10, 'Osward', 'Inicio Sesión', '2016-11-08 14:31:36'), 
(11, 'Osward', 'Inicio Sesión', '2016-11-08 14:33:22'), 
(12, 'Osward', 'Inicio Sesión', '2016-11-08 18:45:00'), 
(13, 'Osward', 'Inicio Sesión', '2016-11-09 19:24:18'), 
(14, 'Osward', 'Inicio Sesión', '2016-11-09 23:32:00'), 
(15, 'Osward', 'Inicio Sesión', '2016-11-10 08:10:20'), 
(16, 'Osward', 'Inicio Sesión', '2016-11-10 22:00:08'), 
(17, 'Osward', 'Inicio Sesión', '2016-11-10 22:00:09'), 
(18, 'Osward', 'Inicio Sesión', '2016-11-11 07:48:58'), 
(19, 'Osward', 'Inicio Sesión', '2016-11-11 15:44:37'), 
(20, 'Osward', 'Inicio Sesión', '2016-11-11 16:39:48'), 
(21, 'Osward', 'Inicio Sesión', '2016-11-12 09:36:06'), 
(22, 'Osward', 'Inicio Sesión', '2016-11-12 09:45:35'), 
(23, 'Osward', 'Inicio Sesión', '2016-11-12 15:08:41'), 
(24, 'Osward', 'Inicio Sesión', '2016-11-12 15:08:43'), 
(25, 'Osward', 'Inicio Sesión', '2016-11-12 17:42:39'), 
(26, 'Osward', 'Inicio Sesión', '2016-11-13 18:42:55'), 
(27, 'Osward', 'Inicio Sesión', '2016-11-13 18:44:22'), 
(28, 'Osward', 'Inicio Sesión', '2016-11-13 18:46:16'), 
(29, 'Osward', 'Inicio Sesión', '2016-11-13 22:09:39'), 
(30, 'Osward', 'Inicio Sesión', '2016-11-16 23:16:25'), 
(31, 'Osward', 'Inicio Sesión', '2016-11-17 11:17:38'), 
(32, 'Osward', 'Inicio Sesión', '2016-11-17 20:55:58'), 
(33, 'Osward', 'Inicio Sesión', '2016-11-17 20:55:59'), 
(34, 'Osward', 'Inicio Sesión', '2016-11-23 23:28:03'), 
(35, 'Osward', 'Inicio Sesión', '2016-11-24 00:26:58'), 
(36, 'Osward', 'Inicio Sesión', '2016-11-24 01:56:54'), 
(37, 'Osward', 'Inicio Sesión', '2016-11-24 10:49:33'), 
(38, 'Osward', 'Inicio Sesión', '2016-11-24 11:04:40'), 
(39, 'Osward', 'Inicio Sesión', '2016-11-25 11:17:57');

-- # Tabel structure for table `categorias`
DROP TABLE  IF EXISTS `categorias`;
CREATE TABLE `categorias` (
  `id_cat` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_cat`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `categorias` (`id_cat`, `nombre`, `descripcion`) VALUES (2, 'Ferretería', '..'), 
(3, 'Químicos', 'De todo tipo');

-- # Tabel structure for table `clientes`
DROP TABLE  IF EXISTS `clientes`;
CREATE TABLE `clientes` (
  `id_cliente` int(11) NOT NULL AUTO_INCREMENT,
  `rif` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `razon_social` text COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` text COLLATE utf8_spanish_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_cliente`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `clientes` (`id_cliente`, `rif`, `razon_social`, `telefono`, `email`, `direccion`, `status`) VALUES (3, 'J-20989357-0', 'Migo, C.A', '0244-3962442', 'ojpr15@gmail.com', 'La Victoria', 'activo'), 
(4, 'J-25065787-0', 'Dev services', '0248-3659841', 'admin@gmail.com', 'direccion. ', 'activo'), 
(5, 'J-25065787-1', 'a', '0248-3659841', 'admin@gmail.com', 'a', 'inactivo'), 
(6, 'J-25065787-2', 'asd', '0248-3659841', 'admin@gmail.com', 'asd', 'inactivo'), 
(7, 'J-03842286-0', 'Alicia Vásquez', '0244-4478908', 'Alicia@hotmail.com', 'La Victoria', 'activo'), 
(8, 'J-25525110-0', 'Gabriel Flores', '0414-5436789', 'Gf@gmail.com', 'a', 'activo'), 
(9, 'J-26180853-0', 'Alexis ', '0244-5667894', 'Alexis@gmail.com', 'La Victoria', 'activo');

-- # Tabel structure for table `compras`
DROP TABLE  IF EXISTS `compras`;
CREATE TABLE `compras` (
  `cod_compra` int(15) NOT NULL,
  `id_prov` int(11) NOT NULL,
  `id_emp` int(10) NOT NULL,
  `fecha_actual` date NOT NULL,
  `forma_pago` enum('efectivo','deposito / transferencia','credito','') COLLATE utf8_spanish_ci NOT NULL,
  `banco` text COLLATE utf8_spanish_ci NOT NULL,
  `nro_cuenta` int(30) NOT NULL,
  `nro_comprobante` int(30) NOT NULL,
  `impuesto` int(10) NOT NULL,
  `subtot` int(10) NOT NULL,
  `tot` int(10) NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`cod_compra`),
  KEY `id_proveedor` (`id_prov`),
  KEY `id_emp` (`id_emp`),
  CONSTRAINT `compras_ibfk_1` FOREIGN KEY (`id_prov`) REFERENCES `proveedores` (`id_prov`),
  CONSTRAINT `compras_ibfk_2` FOREIGN KEY (`id_emp`) REFERENCES `empleados` (`id_emp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `compras` (`cod_compra`, `id_prov`, `id_emp`, `fecha_actual`, `forma_pago`, `banco`, `nro_cuenta`, `nro_comprobante`, `impuesto`, `subtot`, `tot`, `status`) VALUES (1, 25, 1, '2016-10-27', '', '', 0, 0, 600, 5000, 5600, 'activo'), 
(2, 25, 1, '2016-10-27', '', '', 0, 0, 600, 5000, 5600, 'activo'), 
(3, 25, 1, '2016-10-27', '', '', 0, 0, 600, 5000, 5600, 'activo'), 
(4, 25, 1, '2016-10-27', '', 'BNC', 2147483647, 783737, 600, 5000, 5600, 'activo'), 
(5, 25, 1, '2016-10-27', '', '', 0, 0, 600, 5000, 5600, 'activo'), 
(6, 25, 1, '2016-10-27', '', '', 0, 0, 600, 5000, 5600, 'activo'), 
(7, 25, 1, '2016-10-27', '', '', 0, 0, 600, 5000, 5600, 'activo'), 
(8, 25, 1, '2016-10-27', '', 'BFC', 2147483647, 4567654, 600, 5000, 5600, 'activo'), 
(9, 25, 1, '2016-10-27', '', '', 0, 0, 600, 5000, 5600, 'activo'), 
(10, 25, 1, '2016-10-27', '', 'BFC', 2147483647, 42343434, 600, 5000, 5600, 'activo'), 
(11, 25, 1, '2016-10-27', '', 'BFC', 567876567, 6787656, 600, 5000, 5600, 'activo'), 
(12, 25, 1, '2016-10-27', '', 'banesco', 2147483647, 67473673, 600, 5000, 5600, 'activo'), 
(13, 25, 1, '2016-10-27', '', '', 0, 0, 600, 5000, 5600, 'activo'), 
(14, 25, 1, '2016-10-27', '', 'BNC', 2147483647, 2832373, 600, 5000, 5600, 'activo'), 
(15, 25, 1, '2016-10-27', '', '', 0, 0, 600, 5000, 5600, 'activo'), 
(16, 25, 1, '2016-10-27', '', 'BNC', 2147483647, 873973, 600, 5000, 5600, 'activo'), 
(17, 25, 1, '2016-10-27', '', '', 0, 0, 600, 5000, 5600, 'activo'), 
(18, 25, 1, '2016-10-27', '', 'BNC', 2147483647, 345678, 600, 5000, 5600, 'activo'), 
(19, 25, 1, '2016-10-27', '', '', 0, 0, 600, 5000, 5600, 'activo'), 
(20, 25, 1, '2016-10-27', '', 'bfc', 2147483647, 1234567, 600, 5000, 5600, 'activo'), 
(21, 25, 1, '2016-10-27', '', '', 0, 0, 600, 5000, 5600, 'activo'), 
(22, 25, 1, '2016-10-27', '', '', 0, 0, 600, 5000, 5600, 'activo'), 
(23, 25, 1, '2016-10-27', '', 'banesco', 2147483647, 2147483647, 600, 5000, 5600, 'activo'), 
(24, 25, 1, '2016-10-27', '', '', 0, 0, 600, 5000, 5600, 'activo'), 
(25, 25, 1, '2016-10-27', '', 'Catoní', 2147483647, 67655678, 600, 5000, 5600, 'activo'), 
(26, 25, 1, '2016-10-27', '', 'bfc', 2147483647, 2147483647, 600, 5000, 5600, 'activo'), 
(27, 25, 1, '2016-10-27', '', '', 0, 0, 600, 5000, 5600, 'activo'), 
(28, 25, 1, '2016-10-28', '', '', 0, 0, 600, 5000, 5600, 'activo'), 
(29, 25, 1, '2016-10-28', '', 'ddd', 2147483647, 23432, 600, 5000, 5600, 'activo'), 
(30, 25, 1, '2016-10-28', '', 'BFC', 2147483647, 252523, 600, 5000, 5600, 'activo'), 
(31, 25, 1, '2016-10-28', '', '', 0, 0, 600, 5000, 5600, 'activo'), 
(32, 25, 1, '2016-10-28', '', 'BFC', 236543, 3444, 600, 5000, 5600, 'activo'), 
(33, 25, 1, '2016-10-28', '', 'BFC', 534255, 522353, 600, 5000, 5600, 'activo'), 
(34, 25, 1, '2016-10-28', '', 'BFC', 2147483647, 723722, 600, 5000, 5600, 'activo'), 
(35, 25, 1, '2016-10-28', '', 'Banco Mercantil C.A', 2147483647, 76545676, 600, 5000, 5600, 'activo'), 
(36, 25, 1, '2016-10-28', 'deposito / transferencia', 'BFC', 2147483647, 7424387, 600, 5000, 5600, 'activo'), 
(37, 25, 1, '2016-10-28', 'credito', '', 0, 0, 600, 5000, 5600, 'activo'), 
(38, 25, 1, '2016-10-28', 'deposito / transferencia', 'Banco Bicentenario Universal C.A', 2147483647, 2147483647, 600, 5000, 5600, 'activo'), 
(39, 26, 1, '2016-11-08', 'deposito / transferencia', 'Banco bicentenario', 175, 12369874, 3000, 25000, 28000, 'activo'), 
(40, 25, 1, '2016-11-08', 'deposito / transferencia', 'Banesco banco universal', 0, 0, 90, 1000, 1090, 'activo'), 
(41, 25, 1, '2016-11-08', 'deposito / transferencia', 'Antivirus', 23, 23, 1080, 12000, 13080, 'activo'), 
(42, 25, 1, '2016-11-08', '', '', 0, 0, 1080, 12000, 13080, 'activo'), 
(43, 25, 1, '2016-11-08', 'deposito / transferencia', 'Banco de Venezuela', 23232323, 23232, 1080, 12000, 13080, 'activo'), 
(44, 25, 1, '2016-11-08', 'deposito / transferencia', 'Banco Canarias de Venezuela', 343434, 343434, 7650, 85000, 92650, 'activo'), 
(45, 25, 1, '2016-11-24', 'efectivo', '', 0, 0, 550, 4580, 5130, 'activo');

-- # Tabel structure for table `det_compra`
DROP TABLE  IF EXISTS `det_compra`;
CREATE TABLE `det_compra` (
  `cod_compra` int(15) NOT NULL,
  `cod_prod` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `cantidad` int(10) NOT NULL,
  `precio` int(10) NOT NULL,
  KEY `cod_prod` (`cod_prod`),
  KEY `cod_compra` (`cod_compra`),
  CONSTRAINT `det_compra_ibfk_1` FOREIGN KEY (`cod_compra`) REFERENCES `compras` (`cod_compra`),
  CONSTRAINT `det_compra_ibfk_2` FOREIGN KEY (`cod_prod`) REFERENCES `productos` (`cod_prod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `det_compra` (`cod_compra`, `cod_prod`, `cantidad`, `precio`) VALUES (1, 0001, 5, 1000), 
(2, 0001, 5, 1000), 
(3, 0001, 5, 1000), 
(4, 0001, 5, 1000), 
(5, 0001, 5, 1000), 
(6, 0001, 5, 1000), 
(7, 0001, 5, 1000), 
(8, 0001, 5, 1000), 
(9, 0001, 5, 1000), 
(10, 0001, 5, 1000), 
(11, 0001, 5, 1000), 
(12, 0001, 5, 1000), 
(13, 0001, 5, 1000), 
(14, 0001, 5, 1000), 
(15, 0001, 5, 1000), 
(16, 0001, 5, 1000), 
(17, 0001, 5, 1000), 
(18, 0001, 5, 1000), 
(19, 0001, 5, 1000), 
(20, 0001, 5, 1000), 
(21, 0001, 5, 1000), 
(22, 0001, 5, 1000), 
(23, 0001, 5, 1000), 
(24, 0001, 5, 1000), 
(25, 0001, 5, 1000), 
(26, 0001, 5, 1000), 
(27, 0001, 5, 1000), 
(28, 0001, 5, 1000), 
(29, 0001, 5, 1000), 
(30, 0001, 5, 1000), 
(31, 0001, 5, 1000), 
(32, 0001, 5, 1000), 
(33, 0001, 5, 1000), 
(34, 0001, 5, 1000), 
(35, 0001, 5, 1000), 
(36, 0001, 5, 1000), 
(37, 0001, 5, 1000), 
(38, 0001, 5, 1000), 
(39, 004, 10, 2500), 
(40, 0001, 1, 1000), 
(41, 0001, 12, 1000), 
(42, 0001, 12, 1000), 
(43, 0001, 12, 1000), 
(44, 004, 34, 2500), 
(45, 'PIEGRIS005', 10, 458);

-- # Tabel structure for table `det_presu`
DROP TABLE  IF EXISTS `det_presu`;
CREATE TABLE `det_presu` (
  `cod_presu` int(15) NOT NULL,
  `cod_prod` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `cantidad` int(10) NOT NULL,
  `precio` int(10) NOT NULL,
  KEY `cod_prod` (`cod_prod`),
  KEY `cod_presu` (`cod_presu`),
  CONSTRAINT `det_presu_ibfk_1` FOREIGN KEY (`cod_presu`) REFERENCES `presupuestos` (`cod_presu`),
  CONSTRAINT `det_presu_ibfk_2` FOREIGN KEY (`cod_prod`) REFERENCES `productos` (`cod_prod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `det_presu` (`cod_presu`, `cod_prod`, `cantidad`, `precio`) VALUES (1, 0001, 5, 1000), 
(2, 0001, 10, 1000);

-- # Tabel structure for table `det_venta`
DROP TABLE  IF EXISTS `det_venta`;
CREATE TABLE `det_venta` (
  `cod_venta` int(15) NOT NULL,
  `cod_prod` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `cantidad` int(10) NOT NULL,
  `precio` int(10) NOT NULL,
  KEY `cod_prod` (`cod_prod`),
  KEY `cod_venta` (`cod_venta`),
  CONSTRAINT `det_venta_ibfk_1` FOREIGN KEY (`cod_venta`) REFERENCES `ventas` (`cod_venta`),
  CONSTRAINT `det_venta_ibfk_2` FOREIGN KEY (`cod_prod`) REFERENCES `productos` (`cod_prod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `det_venta` (`cod_venta`, `cod_prod`, `cantidad`, `precio`) VALUES (1, 0001, 5, 1000), 
(2, 0001, 5, 1000), 
(3, 0001, 10, 1000), 
(4, 0001, 5, 1000), 
(5, 0001, 5, 1000), 
(6, 0001, 5, 1000), 
(7, 0001, 5, 1000), 
(8, 0001, 5, 1000), 
(9, 0001, 5, 1000), 
(10, 0001, 5, 1000), 
(11, 0001, 5, 1000), 
(12, 0001, 5, 1000), 
(13, 0001, 23, 1000), 
(14, 0001, 12, 1000), 
(15, 'PIEGRIS005', 500, 458), 
(15, 'CORRTEF002', 1100, 3120), 
(16, 'CER025', 5, 11500);

-- # Tabel structure for table `empleados`
DROP TABLE  IF EXISTS `empleados`;
CREATE TABLE `empleados` (
  `id_emp` int(11) NOT NULL AUTO_INCREMENT,
  `ci_usuario` int(10) NOT NULL,
  `primer_nombre` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `primer_apellido` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `username` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `rol` enum('Administrador','empleado','','') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_emp`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `empleados` (`id_emp`, `ci_usuario`, `primer_nombre`, `primer_apellido`, `username`, `password`, `rol`) VALUES (1, 20989357, 'Osward', 'Jr', 'admin', 'admin', 'Administrador');

-- # Tabel structure for table `presupuestos`
DROP TABLE  IF EXISTS `presupuestos`;
CREATE TABLE `presupuestos` (
  `cod_presu` int(15) NOT NULL,
  `id_cliente` int(15) NOT NULL,
  `id_emp` int(15) NOT NULL,
  `fecha_actual` date NOT NULL,
  `fecha_vencimiento` enum('5 Días','','','') COLLATE utf8_spanish_ci NOT NULL,
  `impuesto` int(15) NOT NULL,
  `descuento` int(15) NOT NULL,
  `subtot` int(15) NOT NULL,
  `tot` int(15) NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`cod_presu`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_emp` (`id_emp`),
  CONSTRAINT `presupuestos_ibfk_1` FOREIGN KEY (`id_emp`) REFERENCES `empleados` (`id_emp`),
  CONSTRAINT `presupuestos_ibfk_2` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `presupuestos` (`cod_presu`, `id_cliente`, `id_emp`, `fecha_actual`, `fecha_vencimiento`, `impuesto`, `descuento`, `subtot`, `tot`, `status`) VALUES (1, 3, 1, '2016-11-08', '', 600, 0, 5000, 5600, 'activo'), 
(2, 4, 1, '2016-11-08', '5 Días', 1200, 0, 10000, 11200, 'activo');

-- # Tabel structure for table `productos`
DROP TABLE  IF EXISTS `productos`;
CREATE TABLE `productos` (
  `cod_prod` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `modelo` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `peso` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `color` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `garantia` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `p_compra` int(10) NOT NULL,
  `p_venta` int(10) NOT NULL,
  `stock` int(10) NOT NULL,
  `stock_minimo` int(10) NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8_spanish_ci NOT NULL,
  `procedencia` enum('nacional','internacional') COLLATE utf8_spanish_ci NOT NULL,
  `id_cat` int(11) NOT NULL,
  PRIMARY KEY (`cod_prod`),
  KEY `id_cat` (`id_cat`),
  CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`id_cat`) REFERENCES `categorias` (`id_cat`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `productos` (`cod_prod`, `descripcion`, `modelo`, `peso`, `color`, `garantia`, `p_compra`, `p_venta`, `stock`, `stock_minimo`, `status`, `procedencia`, `id_cat`) VALUES (0001, 'Tornillos', '.', '', '', '', 1000, 1000, 2182, 100, 'inactivo', 'nacional', 2), 
(004, 'asds', 'asd', 2323, 'asd', 34, 2500, 34, 48, 234, 'inactivo', 'nacional', 2), 
('CER025', 'Cerraduras CISA', 'Embutir 25mm', '', '', '', 11500, 11500, 4995, 100, 'activo', 'nacional', 2), 
('CORRTEF002', 'Corredera Telescópica ', 'Ferrari 30cm', '', '', '', 3120, 3120, -100, 100, 'activo', 'nacional', 2), 
('HIERR4421', 'Herramientas Multiuso', 'Premiun', '5kg', 'Negro', '6 meses', 2679, 3350, 1200, 50, 'activo', 'nacional', 2), 
('PIEGRIS005', 'Pie de amigo gris', '12x14', '', '', '', 458, 458, 2510, 150, 'activo', 'internacional', 2), 
('RAMHAIER005', 'Ramplus de hierro', 'Inct 0.5pulg', '', '', '', 192, 350, 1000, 50, 'activo', 'internacional', 2);

-- # Tabel structure for table `proveedores`
DROP TABLE  IF EXISTS `proveedores`;
CREATE TABLE `proveedores` (
  `id_prov` int(11) NOT NULL AUTO_INCREMENT,
  `rif` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `razon_social` text COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` text COLLATE utf8_spanish_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_prov`),
  UNIQUE KEY `rif` (`rif`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `proveedores` (`id_prov`, `rif`, `razon_social`, `telefono`, `email`, `direccion`, `status`) VALUES (25, 'J-20989357-0', 'Migo, C.A', '0244-3962442', 'ojpr15@gmail.com', 'La Victoria', 'activo'), 
(26, 'J-25065787-1', 'asd', '0248-3659841', 'admin@gmail.com', 'asd', 'activo'), 
(27, 'J-20989357-3', '   ', '0424-2552455', 'aloa@hotmail.com', 'Cagua', 'activo');

-- # Tabel structure for table `utilidades`
DROP TABLE  IF EXISTS `utilidades`;
CREATE TABLE `utilidades` (
  `impuesto` int(4) NOT NULL,
  `ven_presu` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `utilidades` (`impuesto`, `ven_presu`) VALUES (12, 5);

-- # Tabel structure for table `ventas`
DROP TABLE  IF EXISTS `ventas`;
CREATE TABLE `ventas` (
  `cod_venta` int(15) NOT NULL,
  `id_cliente` int(15) NOT NULL,
  `id_emp` int(15) NOT NULL,
  `fecha_actual` date NOT NULL,
  `forma_pago` enum('efectivo','deposito / transferencia','credito','') COLLATE utf8_spanish_ci NOT NULL,
  `banco` text COLLATE utf8_spanish_ci NOT NULL,
  `nro_cuenta` int(30) NOT NULL,
  `nro_comprobante` int(30) NOT NULL,
  `impuesto` int(15) NOT NULL,
  `descuento` int(15) NOT NULL,
  `subtot` int(15) NOT NULL,
  `tot` int(15) NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`cod_venta`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_emp` (`id_emp`),
  CONSTRAINT `ventas_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`),
  CONSTRAINT `ventas_ibfk_2` FOREIGN KEY (`id_emp`) REFERENCES `empleados` (`id_emp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `ventas` (`cod_venta`, `id_cliente`, `id_emp`, `fecha_actual`, `forma_pago`, `banco`, `nro_cuenta`, `nro_comprobante`, `impuesto`, `descuento`, `subtot`, `tot`, `status`) VALUES (1, 3, 1, '2016-10-27', '', '', 0, 0, 600, 0, 5000, 5600, 'activo'), 
(2, 3, 1, '2016-10-27', '', 'BNC', 2147483647, 6565456, 600, 0, 5000, 5600, 'activo'), 
(3, 3, 1, '2016-10-27', '', 'BFC', 2147483647, 77396137, 1200, 0, 10000, 11200, 'activo'), 
(4, 3, 1, '2016-10-27', '', '', 0, 0, 600, 0, 5000, 5600, 'activo'), 
(5, 3, 1, '2016-10-27', '', 'BNC', 2147483647, 423434343, 600, 0, 5000, 5600, 'activo'), 
(6, 3, 1, '2016-10-27', '', 'BFC', 2147483647, 253452, 600, 0, 5000, 5600, 'activo'), 
(7, 3, 1, '2016-10-27', '', 'CARONI', 2147483647, 423323233, 600, 0, 5000, 5600, 'activo'), 
(8, 3, 1, '2016-10-28', 'efectivo', '', 0, 0, 600, 0, 5000, 5600, 'activo'), 
(9, 3, 1, '2016-10-28', 'deposito / transferencia', 'BFC C.A', 2147483647, 2147483647, 600, 0, 5000, 5600, 'activo'), 
(10, 3, 1, '2016-10-28', 'credito', '', 0, 0, 600, 0, 5000, 5600, 'activo'), 
(11, 3, 1, '2016-10-28', 'efectivo', '', 0, 0, 600, 0, 5000, 5600, 'activo'), 
(12, 3, 1, '2016-10-28', 'deposito / transferencia', 'bfc', 2147483647, 2147483647, 600, 0, 5000, 5600, 'activo'), 
(13, 3, 1, '2016-11-08', 'deposito / transferencia', 'Banco Canarias de Venezuela', 0, 0, 2760, 207000, 23000, 232760, 'activo'), 
(14, 3, 1, '2016-11-08', 'deposito / transferencia', 'Banco de Venezuela', 34343434, 343434, 1440, 108000, 12000, 121440, 'activo'), 
(15, 3, 1, '2016-11-08', 'deposito / transferencia', 'Banco de Venezuela', 2147483647, 707876, 439320, 43932000, 3661000, 48032320, 'activo'), 
(16, 3, 1, '2016-11-24', 'efectivo', '', 0, 0, 6900, 690000, 57500, 754400, 'activo');

SET FOREIGN_KEY_CHECKS = 1;
COMMIT;
SET AUTOCOMMIT = 1; 
